export default window.CRM.root;
