interface EventType {
  Id: number;
  Name: string;
}

export default EventType;
