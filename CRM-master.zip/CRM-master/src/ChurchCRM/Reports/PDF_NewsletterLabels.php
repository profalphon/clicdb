<?php

namespace ChurchCRM\Reports;

class PdfNewsletterLabels extends PdfLabel
{
    public function __construct($sLabelFormat)
    {
        parent::__construct($sLabelFormat);
    }
}
