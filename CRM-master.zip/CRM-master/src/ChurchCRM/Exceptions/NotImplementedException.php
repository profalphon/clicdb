<?php

namespace ChurchCRM\Exceptions;

class NotImplementedException extends \LogicException
{
}
