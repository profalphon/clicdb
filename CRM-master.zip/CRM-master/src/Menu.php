<?php

//Include the function library
require 'Include/Config.php';

use ChurchCRM\Utils\RedirectUtils;

RedirectUtils::redirect('v2/dashboard');
